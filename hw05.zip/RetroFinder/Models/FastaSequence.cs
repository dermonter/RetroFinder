﻿namespace RetroFinder.Models
{
    public record FastaSequence(string Id, string Sequence);
}
