﻿namespace RetroFinder.Models
{
    public enum FeatureType
    {
        LTRLeft,
        GAG,
        PROT,
        INT,
        RT,
        RH,
        LTRRight
    }
}
