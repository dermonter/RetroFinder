﻿namespace RetroFinder.Output
{
    public class SerializedLocation
    {
        public int Start { get; set; }
        public int End { get; set; }
    }
}
