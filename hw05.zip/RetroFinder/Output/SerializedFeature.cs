﻿namespace RetroFinder.Output
{
    public class SerializedFeature
    {
        public string Type { get; set; }

        public SerializedLocation Location { get; set; }
    }
}
