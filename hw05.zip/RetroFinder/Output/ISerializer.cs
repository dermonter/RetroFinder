﻿namespace RetroFinder.Output
{
    public interface ISerializer
    {
        void SerializeAnalysisResult(SequenceAnalysis analysis);
    }
}
